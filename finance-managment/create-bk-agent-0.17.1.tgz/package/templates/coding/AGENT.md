# My Coding Agent

## Purpose
<!-- Describe what this agent does for your project -->

## Stack
<!-- e.g. Node.js, TypeScript, NestJS, PostgreSQL -->

## Conventions
<!-- Any project-specific coding conventions the agent should follow -->
