# My Coding Agent

TODO: Describe your project here. The agent reads this file to understand the codebase.

## Tech stack
- TODO: list your languages, frameworks, and tools

## Key directories
- `src/` — main source code
- `tests/` — test files

## Coding conventions
- TODO: describe naming conventions, patterns, and rules to follow
